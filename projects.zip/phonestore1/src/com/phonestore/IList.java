package com.phonestore;

import java.util.List;

public interface IList {
    List<PhoneOrder> ordersList(List<PhoneOrder> order);
}
