package com.phonestore;

public interface ICheck {
    public String check();
}
