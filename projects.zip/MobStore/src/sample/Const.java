package sample;

public class Const {
    public static final String USER_TABLE = "users";

    public static final  String USERS_ID = "idusers";
    public static final  String USERS_NAME = "firstname";
    public static final  String USERS_LASTNAME = "lastname";
    public static final  String USERS_USERNAME = "username";
    public static final  String USERS_PASSWORD = "password";
    public static final  String USERS_COUNTRY = "country";
    public static final  String USERS_GENDER = "gender";
}
