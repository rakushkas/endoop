package sample;

public class Configs {
    protected String dbHost = "localhost";
    protected String dbPort = "3306";
    protected String dbUser = "root";
    protected String dbPass = "Kasya1207##";
    protected  String dbName = "phonestore";
}
//jdbc:mysql://127.0.0.1:3306/?user=root